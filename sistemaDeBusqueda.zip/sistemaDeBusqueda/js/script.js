//Función GET a la API
function getPersonas(done) { // Función que trae los datos de la URL

    let results = fetch("https://wp01.anexo328.duckdns.org/wp-json/wc/v3/products?consumer_key=ck_4abb11df3cc1f4502f62c51a764e84932dc8ff60&consumer_secret=cs_630e16f1025ef4c9af90dd50e2a4a1d225093a05"); // Almacena la respuesta en la variable

    results // Trabaja sobre los datos de la variable
        .then(response => response.json()) // Convierte la respuesta a un JSON
        .then(data => { // Pasa el JSON en una callback (Una función call back se crea cuando insertamos una función como valor de un parámetro de otra función.)
            done(data);  // Llama a la función 'done' con los datos obtenidos como argumento
        });
}

// data = Array de objetos

getPersonas(data => {
    console.log(data);

    function mostrarDatos(datos) {
        const article = document.querySelector("article");
        if (article) {
            article.innerHTML = ""; // Limpiar contenido actual
            
            if (datos.length === 0) {
                // Mostrar mensaje específico si no se encontraron datos
                article.innerHTML = `<p style="color: red;">¡Dato no encontrado para la busqueda realizada!</p>`;
            } else {
                datos.forEach(dato => {
                    const productoImagen = dato.images.length > 0 ? dato.images[0].src : "Imagen no encontrada";
                    const div = document.createRange().createContextualFragment(/*HTML*/`
                    <div class="item">
                        <h2> ID: ${dato.id}</h2>
                        <span> Producto: ${dato.name}</span>
                        <span> Descripción: ${dato.description}</span>
                        <span> Precio: $${dato.price}</span>
                        <img src="${productoImagen}" alt="Imagen no encontrada"> 
                    </div>
                    `);
                    article.append(div);
                });
            }
        }
    }


    const filtroInput = document.getElementById("filtro");
    const filtrarBtn = document.getElementById("filtrarBtn");
    const resetBtn = document.getElementById("resetBtn");

    filtrarBtn.addEventListener("click", () => {
        const filtro = filtroInput.value.trim(); // Obtener y limpiar el valor del input
    
        let datosFiltrados;
    
        if (filtro) {
            // Intentar convertir el valor del filtro a un número
            const filtroNumerico = Number(filtro);
    
            if (!isNaN(filtroNumerico)) {
                // Filtrar por id cuando el filtro es un número
                datosFiltrados = data.filter(dato => dato.id === filtroNumerico);
            } else {
                // Filtrar por nombre si el filtro no es un número
                datosFiltrados = data.filter(dato => dato.name.toLowerCase().includes(filtro.toLowerCase()));
            }
    
            if (datosFiltrados.length === 0) {
                mostrarDatos([]); // Mostrar mensaje de dato no encontrado
            } else {
                mostrarDatos(datosFiltrados); // Mostrar los datos filtrados
            }
        } else {
            mostrarDatos(data); // Si no hay filtro, mostrar todos los datos
        }
        filtroInput.value = ""; // Limpiar el input después de filtrar
    });
    

    if (resetBtn) {
        resetBtn.addEventListener("click", () => {
            mostrarDatos(data); // Mostrar todos los datos
            filtroInput.value = ""; // Limpiar el input
        });
    }

    mostrarDatos(data); // Mostrar todos los datos inicialmente
});