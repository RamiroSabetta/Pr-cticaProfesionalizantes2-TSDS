//Función GET a la API
function getProductos(done) { // Función que trae los datos de la URL

    let url = "https://wp01.anexo328.duckdns.org/wp-json/wc/v3/products?consumer_key=ck_4abb11df3cc1f4502f62c51a764e84932dc8ff60&consumer_secret=cs_630e16f1025ef4c9af90dd50e2a4a1d225093a05" // Le asigno la url a una variable y paso esa variable al fetch

    let results = fetch(url); // Almacena la respuesta en la variable

    results // Trabaja sobre los datos de la variable
        .then(response => response.json()) // Convierte la respuesta a un JSON
        .then(data => { // Pasa el JSON en una callback (Una función call back se crea cuando insertamos una función como valor de un parámetro de otra función.)
            done(data);  // Llama a la función 'done' con los datos obtenidos como argumento
        });
}

// Ver lo que tiene data

getProductos(data => {
    console.log(data);
});